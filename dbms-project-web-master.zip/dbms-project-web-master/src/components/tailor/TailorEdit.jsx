import React from "react";

const TailorEdit = () => {
  return (
    <div className="TailorEdit-wrapper">
      <h1>Tailor Edit</h1>
    </div>
  );
};

export default TailorEdit;
