import React from "react";

const TailorDelete = () => {
  return (
    <div className="TailorDelete-wrapper">
      <h1>Tailor Delete</h1>
    </div>
  );
};

export default TailorDelete;
