import React from "react";

const TailorAdd = () => {
  return (
    <div className="TailorAdd-wrapper">
      <h1>Tailor Add</h1>
    </div>
  );
};

export default TailorAdd;
