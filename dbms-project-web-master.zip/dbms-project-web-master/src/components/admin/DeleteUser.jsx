import React from "react";
import AdminHeader from "./AdminHeader";

import "./Admin.css";

const DeleteUser = () => {
  return (
    <div className="DeleteUser-wrapper">
      <AdminHeader />
      <h1>Delete User</h1>
    </div>
  );
};

export default DeleteUser;
