import React from "react";
import AdminHeader from "./AdminHeader";

import "./Admin.css";

const EditUser = () => {
  return (
    <div className="EditUser-wrapper">
      <AdminHeader />
      <h1>Edit User</h1>
    </div>
  );
};

export default EditUser;
