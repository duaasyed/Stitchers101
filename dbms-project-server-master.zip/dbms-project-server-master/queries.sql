INSERT INTO category (name, description, stock, picture_link)
VALUES (
        "Women",
        "Discover the latest dresses with Stitchers101. Shop from a range of lengths, colours and styles for the day, evening or any occasion from your favourite brands",
        0,
        "https://i.ibb.co/WFxw7yc/Women.jpg"
    );