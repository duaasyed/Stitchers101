# DBMS Project

Backend of my DBMS Project

Frameworks + Languages + Database used:
1. NodeJS
2. ExpressJS
3. Sequelize ORM
4. PostgreSQL
5. For user aunthetication/authorization, JWT is used